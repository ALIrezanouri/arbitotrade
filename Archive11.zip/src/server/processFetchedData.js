import fs from "fs";
import path from "path";

const exchangesPath = path.resolve("./src/server/", "exchange_names.json");
const exchangesJson = JSON.parse(fs.readFileSync(exchangesPath, "utf-8")); //load exchange names
const exchanges = exchangesJson.exchange;

function processFetchedData_USDT({ ordersAndExchanges, firstLiners, asset }) {
  for (let i = 0; i < Object.keys(ordersAndExchanges).length; i++) {
    switch (Object.keys(ordersAndExchanges)[i]) {
      case "RAMZINEX":
        if (ordersAndExchanges.RAMZINEX !== null) {
          firstLiners.RAMZINEX[asset].bestBid.price = parseFloat(
            ordersAndExchanges.RAMZINEX.data.buys[0][0]
          );
          firstLiners.RAMZINEX[asset].bestBid.vol = parseFloat(
            ordersAndExchanges.RAMZINEX.data.buys[0][1]
          );
          firstLiners.RAMZINEX[asset].bestAsk.price = parseFloat(
            ordersAndExchanges.RAMZINEX.data.sells.reverse()[0][0]
          );
          firstLiners.RAMZINEX[asset].bestAsk.vol = parseFloat(
            ordersAndExchanges.RAMZINEX.data.sells.reverse()[0][1]
          );
        } else {
          firstLiners.RAMZINEX[asset].bestBid.price = null;
          firstLiners.RAMZINEX[asset].bestBid.vol = null;
          firstLiners.RAMZINEX[asset].bestAsk.price = null;
          firstLiners.RAMZINEX[asset].bestAsk.vol = null;
        }
        break;

      case "EXIR":
        if (ordersAndExchanges.EXIR !== null) {
          firstLiners.EXIR[asset].bestBid.price = parseFloat(
            ordersAndExchanges.EXIR[asset].bids[0][0]
          );
          firstLiners.EXIR[asset].bestBid.vol = parseFloat(
            ordersAndExchanges.EXIR[asset].bids[0][1]
          );
          firstLiners.EXIR[asset].bestAsk.price = parseFloat(
            ordersAndExchanges.EXIR[asset].asks[0][0]
          );
          firstLiners.EXIR[asset].bestAsk.vol = parseFloat(
            ordersAndExchanges.EXIR[asset].asks[0][1]
          );
        } else {
          firstLiners.EXIR[asset].bestBid.price = null;
          firstLiners.EXIR[asset].bestBid.vol = null;
          firstLiners.EXIR[asset].bestAsk.price = null;
          firstLiners.EXIR[asset].bestAsk.vol = null;
        }
        break;

      case "NOBITEX":
        if (ordersAndExchanges.NOBITEX !== null) {
          firstLiners.NOBITEX[asset].bestBid.price = parseFloat(
            ordersAndExchanges.NOBITEX.bids[0][0]
          );
          firstLiners.NOBITEX[asset].bestBid.vol = parseFloat(
            ordersAndExchanges.NOBITEX.bids[0][1]
          );
          firstLiners.NOBITEX[asset].bestAsk.price = parseFloat(
            ordersAndExchanges.NOBITEX.asks[0][0]
          );
          firstLiners.NOBITEX[asset].bestAsk.vol = parseFloat(
            ordersAndExchanges.NOBITEX.asks[0][1]
          );
        } else {
          firstLiners.NOBITEX[asset].bestBid.price = null;
          firstLiners.NOBITEX[asset].bestBid.vol = null;
          firstLiners.NOBITEX[asset].bestAsk.price = null;
          firstLiners.NOBITEX[asset].bestAsk.vol = null;
        }
        break;

      case "WALLEX":
        if (ordersAndExchanges.WALLEX !== null) {
          firstLiners.WALLEX[asset].bestBid = {
            price: parseFloat(ordersAndExchanges.WALLEX.result.bid[0].price),
            vol: parseFloat(ordersAndExchanges.WALLEX.result.bid[0].quantity),
          };
          firstLiners.WALLEX[asset].bestAsk = {
            price: parseFloat(ordersAndExchanges.WALLEX.result.ask[0].price),
            vol: parseFloat(ordersAndExchanges.WALLEX.result.ask[0].quantity),
          };
        } else {
          firstLiners.WALLEX[asset].bestBid = {
            price: null,
            vol: null,
          };
          firstLiners.WALLEX[asset].bestAsk = {
            price: null,
            vol: null,
          };
        }
        break;

      case "LBANK":
        if (ordersAndExchanges.LBANK !== null) {
          firstLiners.LBANK[asset].bestBid.price = parseFloat(
            ordersAndExchanges.LBANK.data.asks[0][0]
          );
          firstLiners.LBANK[asset].bestBid.vol = parseFloat(
            ordersAndExchanges.LBANK.data.asks[0][1]
          );
          firstLiners.LBANK[asset].bestAsk.price = parseFloat(
            ordersAndExchanges.LBANK.data.bids[0][0]
          );
          firstLiners.LBANK[asset].bestAsk.vol = parseFloat(
            ordersAndExchanges.LBANK.data.bids[0][1]
          );
        } else {
          firstLiners.LBANK[asset].bestBid.price = null;
          firstLiners.LBANK[asset].bestBid.vol = null;
          firstLiners.LBANK[asset].bestAsk.price = null;
          firstLiners.LBANK[asset].bestAsk.vol = null;
        }
        break;
    }
  }
  let newDate = new Date();
  const tehranTimeOptions = { timeZone: "Asia/Tehran", hour12: false };
  console.log(
    new Intl.DateTimeFormat("en-GB", {
      ...tehranTimeOptions,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).format(newDate)
  );
  return firstLiners;
}

function processFetchedData_IRT({ ordersAndExchanges, firstLiners, asset }) {
  for (let i = 0; i < Object.keys(ordersAndExchanges).length; i++) {
    switch (Object.keys(ordersAndExchanges)[i]) {
      case "RAMZINEX":
        if (ordersAndExchanges.RAMZINEX !== null) {
          firstLiners.RAMZINEX[asset].bestBid.price =
            parseFloat(ordersAndExchanges.RAMZINEX.data.buys[0][0]) / 10;
          firstLiners.RAMZINEX[asset].bestBid.vol =
            parseFloat(ordersAndExchanges.RAMZINEX.data.buys[0][1]) / 10;
          firstLiners.RAMZINEX[asset].bestAsk.price =
            parseFloat(ordersAndExchanges.RAMZINEX.data.sells.reverse()[0][0]) /
            10;
          firstLiners.RAMZINEX[asset].bestAsk.vol =
            parseFloat(ordersAndExchanges.RAMZINEX.data.sells.reverse()[0][1]) /
            10;
        } else {
          firstLiners.RAMZINEX[asset].bestBid.price = null;
          firstLiners.RAMZINEX[asset].bestBid.vol = null;
          firstLiners.RAMZINEX[asset].bestAsk.price = null;
          firstLiners.RAMZINEX[asset].bestAsk.vol = null;
        }
        break;

      case "EXIR":
        if (ordersAndExchanges.EXIR !== null) {
          firstLiners.EXIR[asset].bestBid.price = parseFloat(
            ordersAndExchanges.EXIR[asset].bids[0][0]
          );
          firstLiners.EXIR[asset].bestBid.vol = parseFloat(
            ordersAndExchanges.EXIR[asset].bids[0][1]
          );
          firstLiners.EXIR[asset].bestAsk.price = parseFloat(
            ordersAndExchanges.EXIR[asset].asks[0][0]
          );
          firstLiners.EXIR[asset].bestAsk.vol = parseFloat(
            ordersAndExchanges.EXIR[asset].asks[0][1]
          );
        } else {
          firstLiners.EXIR[asset].bestBid.price = null;
          firstLiners.EXIR[asset].bestBid.vol = null;
          firstLiners.EXIR[asset].bestAsk.price = null;
          firstLiners.EXIR[asset].bestAsk.vol = null;
        }
        break;

      case "NOBITEX":
        if (ordersAndExchanges.NOBITEX !== null) {
          firstLiners.NOBITEX[asset].bestBid.price =
            parseFloat(ordersAndExchanges.NOBITEX.bids[0][0]) / 10;
          firstLiners.NOBITEX[asset].bestBid.vol =
            parseFloat(ordersAndExchanges.NOBITEX.bids[0][1]) / 10;
          firstLiners.NOBITEX[asset].bestAsk.price =
            parseFloat(ordersAndExchanges.NOBITEX.asks[0][0]) / 10;
          firstLiners.NOBITEX[asset].bestAsk.vol =
            parseFloat(ordersAndExchanges.NOBITEX.asks[0][1]) / 10;
        } else {
          firstLiners.NOBITEX[asset].bestBid.price = null;
          firstLiners.NOBITEX[asset].bestBid.vol = null;
          firstLiners.NOBITEX[asset].bestAsk.price = null;
          firstLiners.NOBITEX[asset].bestAsk.vol = null;
        }
        break;

      case "WALLEX":
        if (ordersAndExchanges.WALLEX !== null) {
          firstLiners.WALLEX[asset].bestBid = {
            price: parseFloat(ordersAndExchanges.WALLEX.result.bid[0].price),
            vol: parseFloat(ordersAndExchanges.WALLEX.result.bid[0].quantity),
          };
          firstLiners.WALLEX[asset].bestAsk = {
            price: parseFloat(ordersAndExchanges.WALLEX.result.ask[0].price),
            vol: parseFloat(ordersAndExchanges.WALLEX.result.ask[0].quantity),
          };
        } else {
          firstLiners.WALLEX[asset].bestBid = {
            price: null,
            vol: null,
          };
          firstLiners.WALLEX[asset].bestAsk = {
            price: null,
            vol: null,
          };
        }
        break;

      case "LBANK":
        if (ordersAndExchanges.LBANK !== null) {
          firstLiners.LBANK[asset].bestBid.price = parseFloat(
            ordersAndExchanges.LBANK.data.asks[0][0]
          );
          firstLiners.LBANK[asset].bestBid.vol = parseFloat(
            ordersAndExchanges.LBANK.data.asks[0][1]
          );
          firstLiners.LBANK[asset].bestAsk.price = parseFloat(
            ordersAndExchanges.LBANK.data.bids[0][0]
          );
          firstLiners.LBANK[asset].bestAsk.vol = parseFloat(
            ordersAndExchanges.LBANK.data.bids[0][1]
          );
        } else {
          firstLiners.LBANK[asset].bestBid.price = null;
          firstLiners.LBANK[asset].bestBid.vol = null;
          firstLiners.LBANK[asset].bestAsk.price = null;
          firstLiners.LBANK[asset].bestAsk.vol = null;
        }
        break;
    }
  }
  let newDate = new Date();
  const tehranTimeOptions = { timeZone: "Asia/Tehran", hour12: false };
  console.log(
    new Intl.DateTimeFormat("en-GB", {
      ...tehranTimeOptions,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).format(newDate)
  );
  return firstLiners;
}

function findMinMaxPrices(firstLiners, asset) {
  let allBestOrders = {};

  let maxBestBid = { price: -Infinity, vol: null, exchange: null };
  let minBestAsk = { price: Infinity, vol: null, exchange: null };

  for (let exchange of exchanges) {
    const bestBid = firstLiners[exchange][asset].bestBid;
    const bestAsk = firstLiners[exchange][asset].bestAsk;

    if (bestBid.price !== null && bestBid.price > maxBestBid.price) {
      maxBestBid = { price: bestBid.price, vol: bestBid.vol, exchange };
    }

    if (bestAsk.price !== null && bestAsk.price < minBestAsk.price) {
      minBestAsk = { price: bestAsk.price, vol: bestAsk.vol, exchange };
    }
  }

  allBestOrders[asset] = { maxBestBid, minBestAsk };

  return allBestOrders;
}

export { processFetchedData_USDT, processFetchedData_IRT, findMinMaxPrices };
