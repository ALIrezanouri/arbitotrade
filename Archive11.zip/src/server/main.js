import { getAllCoins } from "./getAndProcessOperation.js";


async function runGetAllCoinsAtIntervals() {
  await getAllCoins(); // Run immediately
  setInterval(async () => {
    await getAllCoins();
  }, 20000); // this should be bigger than the perfomance time of getAllCoins
}

runGetAllCoinsAtIntervals();
