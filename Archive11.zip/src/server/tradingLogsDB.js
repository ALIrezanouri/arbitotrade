import sqlite3 from "sqlite3";
sqlite3.verbose();

async function logTradeDB(tradeLog) {
  let tradeLogs = new sqlite3.Database("./src/server/tradeLogs.db");

  try {
    tradeLogs.serialize(() => {
      tradeLogs.run(`
        CREATE TABLE IF NOT EXISTS tradeHistory (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          profitPercent TEXT,
          profitNet TEXT,
          tradeVolBase TEXT,
          tradeVolQuote TEXT,
          buyAt TEXT,
          sellAt TEXT,
          buyPrice NUMBER,
          sellPrice NUMBER,
          date TEXT,
          time TEXT
        )
      `);

      let stmt = tradeLogs.prepare(`
        INSERT INTO tradeHistory (profitPercent, profitNet, "tradeVolBase", "tradeVolQuote", "buyAt", "sellAt", buyPrice, sellPrice, date, time)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run(
        tradeLog.profitPercent,
        tradeLog.profitNet,
        tradeLog.tradeVolBase,
        tradeLog.tradeVolQuote,
        tradeLog.buyAt,
        tradeLog.sellAt,
        tradeLog.buyPrice,
        tradeLog.sellPrice,
        tradeLog.date,
        tradeLog.time
      );

      stmt.finalize();
    });
  } catch (error) {
    console.error("Error logging trade to database:", error);
  } finally {
    tradeLogs.close();
  }
}

export { logTradeDB };
