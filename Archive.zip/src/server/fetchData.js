import fs from "fs";
import path from "path";

const exchangesPath = path.resolve("./", "exchange_names.json");
const exchangesJson = JSON.parse(fs.readFileSync(exchangesPath, "utf-8")); //load exchange names
const exchanges = exchangesJson.exchange;

const configPath = path.resolve("./", "exchange_api_public.json");
const URLs = JSON.parse(fs.readFileSync(configPath, "utf-8")); //load urls

async function performFetch(address) {
  //fetch data from exchanges
  try {
    const marketData = await fetch(address, {
      method: "GET",
      redirect: "follow",
    });
    if (!marketData) {
      throw new Error(`error! status: ${marketData.status}`);
    }
    return await marketData.json();
  } catch (error) {
    console.error(`Error fetching ${address}:`, error);
    return null; // Return null or for failed requests so that the program can continue
  }
}

async function fetchAssetData(asset) {
  try {
    let request = [];
    request = exchanges.map((exchange) => performFetch(URLs[exchange][asset]));
    const result = await Promise.all(request);

    let ordersAndExchanges = {};

    for (let i = 0; i < exchanges.length; i++) {
      ordersAndExchanges[exchanges[i]] = result[i];
    }

    let firstLiners = {};

    for (let exchange of exchanges) {
      firstLiners[exchange] = {
        [asset]: {
          bestBid: {},
          bestAsk: {},
        },
      };
    }

    return { ordersAndExchanges, firstLiners, asset };
  } catch (error) {
    console.error(`Error in fetching data for ${asset}:`, error);
  }
}

export { fetchAssetData }; 