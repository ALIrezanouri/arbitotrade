import dotenv from "dotenv";
dotenv.config();

const wallex_api_key = process.env.WALLEX_API_KEY;
const nobitex_api_token = process.env.NOBITEX_API_TOKEN;
// const ramzinex_api_key = process.env.RAMZINEX_API_KEY;
// const ramzinex_api_token = process.env.RAMZINEX_API_TOKEN;
// const exir_api_key = process.env.EXIR_API_KEY;
// const exir_api_expires = process.env.EXIR_API_EXPIRES;
// const exir_api_signature = process.env.EXIR_API_SIGNATURE;

async function tradeExec(exchange, pair, side, price, volume) {
  // EXCHANGE IN CAPS, pair in lowercase with dash (btc-irt) , price usdt or toman, volume in src coin like btc or ..
  const myHeaders = new Headers();
  const data = "";

  function isIrtAfterDash(pair) {
    const parts = pair.toLowerCase().split("-");
    return parts.length === 2 && parts[1] === "irt";
  }
  const isIRT = isIrtAfterDash(pair);

  // **** make body and header based on the exchange
  switch (exchange) {
    case "RAMZINEX": //must be completed with api key and signature when adding to the project
      myHeaders.append("Content-Type", "application/json");
      myHeaders.append("Authorization", ramzinex_api_token);
      data = JSON.stringify({
        pair_id: tradeParams.RAMZINEX.symbol[pair],
        amount: parseFloat(volume),
        price: parseFloat(isIRT ? price * 10 : price),
        type: tradeParams.RAMZINEX.order.side[side],
      });
      break;

    case "EXIR": //must be completed with api key and signature when adding to the project
      myHeaders.append("api-key", exir_api_key);
      myHeaders.append("api-signature", exir_api_signature);
      myHeaders.append("api-expires", exir_api_expires);
      myHeaders.append("Content-Type", "application/json");
      data = JSON.stringify({
        symbol: tradeParams.EXIR.symbol[pair],
        size: parseFloat(volume),
        price: parseFloat(price),
        side: tradeParams.EXIR.order.side[side],
      });
      break;

    case "NOBITEX":
      myHeaders.append("Authorization", `Token ${nobitex_api_token}`);
      data = JSON.stringify({
        srcCurrency: pair.toLowerCase().split("-")[0],
        dstCurrency: isIRT ? "rls" : "usdt",
        amount: parseFloat(volume),
        price: parseFloat(isIRT ? price * 10 : price),
        type: tradeParams.NOBITEX.order.side[side],
        clientOrcderId: null,
      });
      break;

    case "WALLEX":
      myHeaders.append("Content-Type", "application/json");
      myHeaders.append("X-API-Key", wallex_api_key);
      data = JSON.stringify({
        symbol: tradeParams.WALLEX.symbol[pair],
        quantity: parseFloat(volume),
        price: parseFloat(price),
        side: tradeParams.WALLEX.order.side[side],
        type: "LIMIT",
        client_id: null,
      });
      break;

    default:
      console.log("Invalid exchange");
  }

  const requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: data,
    redirect: "follow",
  };

  let status = null;

  fetch(tradeParams[exchange].order.url, requestOptions)
    .then((response) => {
      status = response.status;
      return response.text(); 
    })
    .then((result) => console.log(`${exchange} : ${result}`)) 
    .catch((error) => console.error(`${exchange} : ${error}`));

  return status;
}

export { tradeExec };
