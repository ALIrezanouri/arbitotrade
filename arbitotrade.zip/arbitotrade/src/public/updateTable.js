// Function to update the table with new data
function updateTable(data) {
  const tableBody = document.getElementById('tableBody');
  tableBody.innerHTML = ''; // Clear existing rows

  data.forEach(row => {
    console.log('Row data:', row); // Log the row data to check tradeVolBase and tradeVolQuote

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${row.id}</td>
      <td>${row.profitPercent}</td>
      <td>${row.profitNet}</td>
      <td>${row.tradeVolBase}</td>
      <td>${row.tradeVolQuote}</td>
      <td>${row.buyAt}</td>
      <td>${row.sellAt}</td>
      <td>${row.buyPrice}</td>
      <td>${row.sellPrice}</td>
      <td>${row.date}</td>
      <td>${row.time}</td>
    `;
    tableBody.appendChild(tr);
  });
}

// Function to fetch data from the API
async function fetchData() {
  try {
    const response = await fetch('http://localhost:3003/api/tradeHistory');
    const data = await response.json();
    updateTable(data.data);
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

// Pause function to delay the initial fetch
function pause(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Wait for the endpoint to be live before starting the initial fetch
async function startFetching() {
  await pause(5000); // Pause for 5 seconds
  fetchData();
  setInterval(fetchData, 5000); // Fetch data every 5 seconds
}

// Start fetching data
startFetching();
