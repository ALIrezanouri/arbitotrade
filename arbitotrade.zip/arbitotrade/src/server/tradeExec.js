function tradeExec(exchange, pair, side, price, volume) { // EXCHANGE IN CAPS, pair in lowercase with dash (btc-irt) , price usdt or toman, volume in src coin like btc or .. 
  const myHeaders = new Headers();
  const data = "";

  function isIrtAfterDash(pair) {
    const parts = pair.toLowerCase().split("-");
    return parts.length === 2 && parts[1] === "irt";
  }
  const isIRT = isIrtAfterDash(pair);

  // **** make body and header based on the exchange
  switch (exchange) {
    case "RAMZINEX":
      myHeaders.append({
        "Content-Type": "application/json",
        Authorization2: "Bearer token",
        "x-api-key": "key",
      });
      data = JSON.stringify({
        pair_id: tradeParams.RAMZINEX.symbol[pair],
        amount: volume,
        price: isIRT ? price * 10 : price,
        type: tradeParams.RAMZINEX.order.side[side],
      });
      break;

    case "EXIR":
      myHeaders.append({
        "Content-Type": "application/json",
        "api-key": "api_key",
        "api-signature": "api-signature",
        "api-expires": "api-expires",
      });
      data = JSON.stringify({
        symbol: tradeParams.EXIR.symbol[pair],
        size: volume,
        price: price,
        side: tradeParams.EXIR.order.side[side],
      });
      break;

    case "NOBITEX":
      myHeaders.append({
        "Content-Type": "application/json",
        "api-key": "api_key",
        "api-signature": "api-signature",
        "api-expires": "api-expires",
      });
      data = JSON.stringify({
        srcCurrency: pair.toLowerCase().split("-")[0],
        dstCurrency: isIRT ? "rls" : "usdt",
        amount: volume,
        price: isIRT ? price * 10 : price,
        type: tradeParams.NOBITEX.order.side[side],
        clientOrcderId: null,
      });
      break;

    case "WALLEX":
      myHeaders.append({
        "Content-Type": "application/json",
        "X-API-Key": "api_key",
      });
      data = JSON.stringify({
        symbol: tradeParams.WALLEX.symbol[pair],
        quantity: volume,
        price: price,
        side: tradeParams.WALLEX.order.side[side],
        type: "LIMIT",
        client_id: null,
      });
      break;

    default:
      console.log("Invalid exchange");
  }

  const requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: data,
    redirect: "follow",
  };

  fetch(tradeParams[exchange].order.url, requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.error(error));
}
