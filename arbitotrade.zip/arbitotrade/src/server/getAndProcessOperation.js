// adjustedConstantForateLimit in milliseconds to adjust for rate limit (creates a little pause between requests in each loop iteration)
import { fetchAssetData } from "./fetchData.js";
import {
  processFetchedData_IRT,
  processFetchedData_USDT,
  findMinMaxPrices,
} from "./processFetchedData.js";
import { logTrade } from "./tradingLogsDB.js";
import fs from "fs";
import path from "path";

const assetsPath = path.resolve("./src/server", "assets.json");
const assetsJson = JSON.parse(fs.readFileSync(assetsPath, "utf-8")); // load assets

const assets = assetsJson.crypto.token_irt; // set the market base currency token_usdt or token_irt

const isUSDT_Market = assets === assetsJson.crypto.token_usdt ? true : false; // set the market base currency token_usdt or token_irt
const tradeParamsPath = path.resolve("./src/server", "trade_params.json");
const tradeParams = JSON.parse(fs.readFileSync(tradeParamsPath, "utf-8")); //load trading fees and request params
const adjustedConstantForateLimit = 1000; // in milliseconds to adjust for rate limit (creates a little pause between requests in each loop iteration)
const min_profit = isUSDT_Market
  ? tradeParams.arbitrage.net_min_profit_usdt
  : tradeParams.arbitrage.net_min_profit_irt;

const max_volume = isUSDT_Market
  ? tradeParams.arbitrage.max_volume_usdt
  : tradeParams.arbitrage.max_volume_irt;

const min_profit_percent = isUSDT_Market
  ? tradeParams.arbitrage.percent_min_profit_usdt
  : tradeParams.arbitrage.percent_min_profit_irt;
const tehranTimeOptions = {
  hour: "numeric",
  minute: "numeric",
  second: "numeric",
  hour12: false,
  timeZone: "Asia/Tehran",
};
const tehranDateOptions = {
  timeZone: "Asia/Tehran",
  year: "numeric",
  month: "numeric",
  day: "numeric",
};

const dateFormatter = new Intl.DateTimeFormat("en-US", tehranDateOptions);
const timeFormatter = new Intl.DateTimeFormat("en-US", tehranTimeOptions);

async function getAllCoins() {
  let allBestOrders = [];
  // *** if no rate limit, we could do this block in parallel ***
  for (const asset of assets) {
    console.log(`Processin: ${asset}`);
    try {
      const fetchedData = await fetchAssetData(asset);
      const firstLineOrders = isUSDT_Market
        ? processFetchedData_USDT(fetchedData)
        : processFetchedData_IRT(fetchedData);
      const bestAskBid = findMinMaxPrices(firstLineOrders, asset);
      console.log(`****** ${asset} data grabbed.....`);
      const bestForSellerPrice = bestAskBid[asset].maxBestBid.price;
      const bestForBuyerPrice = bestAskBid[asset].minBestAsk.price;
      const bestForSellerExchange = bestAskBid[asset].maxBestBid.exchange;
      const bestForBuyerExchange = bestAskBid[asset].minBestAsk.exchange;
      const bestForSellerVol = bestAskBid[asset].maxBestBid.vol;
      const bestForBuyerVol = bestAskBid[asset].minBestAsk.vol;
      const tradeVol = Math.min(bestForSellerVol, bestForBuyerVol);
      const feeSeller =
        tradeParams[bestForSellerExchange].fee.usdt.taker *
        tradeVol *
        bestForSellerPrice;
      const feeBuyer =
        tradeParams[bestForBuyerExchange].fee.usdt.taker *
        tradeVol *
        bestForBuyerPrice;
      const feeTotal = feeSeller + feeBuyer;
      const profitNet =
        (bestForSellerPrice - bestForBuyerPrice) * tradeVol - feeTotal;
      const profitPercent = (profitNet * 100) / (tradeVol * bestForSellerPrice);
      const tradeVolumeFiat = tradeVol * bestForSellerPrice;

      if (
        tradeVol < max_volume &&
        profitNet > min_profit &&
        profitPercent > min_profit_percent
      ) {
        console.log(
          `*** 🚨🚨🚨 profitable arbitrage found for ${asset} 🚨🚨🚨***`
        );
        const tradeLog = {
          profitPercent: `${profitPercent.toFixed(3)} %`,
          profitNet: `${profitNet.toFixed(3)} ${asset.split("-")[1]}`,
          tradeVolBase: `${tradeVol} ${asset.split("-")[0]}`,
          tradeVolQuote: `${tradeVolumeFiat} ${asset.split("-")[1]}`,
          buyAt: bestForBuyerExchange,
          sellAt: bestForSellerExchange,
          buyPrice: bestForBuyerPrice,
          sellPrice: bestForSellerPrice,
          date: dateFormatter.format(new Date()),
          time: timeFormatter.format(new Date()),
        };
        try {
          await logTrade(tradeLog);
        } catch (error) {
          console.error(`Error in logging trade for ${asset}:`, error);
        }
        console.table(tradeLog);
      }
    } catch (error) {
      console.error(`Error in fetching data for ${asset}:`, error);
    }

    await new Promise((resolve) =>
      setTimeout(() => {
        console.log(`*** waiting before grabing next coin data.....`);
        resolve();
      }, adjustedConstantForateLimit)
    );
  }
  return allBestOrders;
}

export { getAllCoins };
