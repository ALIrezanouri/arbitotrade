import express from "express";
import sqlite3 from "sqlite3";
import cors from "cors";

sqlite3.verbose();

// Set up Express server
const app = express();
const port = 3003;

// Use the CORS middleware
app.use(cors());

// Open SQLite database
const db = new sqlite3.Database("./src/server/tradeLogs.db", (err) => {
  if (err) {
    console.error("Error opening database:", err.message);
  } else {
    console.log("Connected to the SQLite database.");
  }
});

// Serve the static files (web page)
app.use(express.static("public"));

let tradeHistoryCache = [];
let lastFetchTime = null;

// Function to fetch data from SQLite
const fetchTradeHistory = () => {
  db.all(
    "SELECT * FROM tradeHistory ORDER BY id DESC LIMIT 300",
    (err, rows) => {
      if (err) {
        console.error("Error fetching data:", err.message);
      } else {
        tradeHistoryCache = rows;
      }
    }
  );
  lastFetchTime = new Date().toISOString();
};

// Initial fetch
fetchTradeHistory();
// Fetch data every 5 seconds
setInterval(fetchTradeHistory, 5000);

// Create an endpoint to fetch data from cache
app.get("/api/tradeHistory", (_req, res) => {
  res.json({ data: tradeHistoryCache ? tradeHistoryCache : [], lastFetchTime });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
