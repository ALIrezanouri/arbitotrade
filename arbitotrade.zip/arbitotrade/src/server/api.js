import express from "express";
import { startBot, dataToPublish, lastFetchTime } from "./telbot.js";

const app = express();
const port = 3001;

app.get("/api/data", (req, res) => {
  res.json({ data: dataToPublish ? dataToPublish : [], lastFetchTime });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
  startBot(); // Start the bot immediately
  setInterval(() => {
    startBot(); // Start the bot every 15 minutes
  }, 900000); // 15 minutes
});
