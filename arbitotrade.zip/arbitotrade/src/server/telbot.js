import { getAllCoins } from "./getBestOrders.js";
import nodeTelegramBotApi from "node-telegram-bot-api";

let dataToPublish = []
let lastFetchTime = null
const TelegramBot = nodeTelegramBotApi;

const botToken = "7929128832:AAG4z6nAeorh8yDCXEK5vZviAAi9ZkYCfhs";
const bot = new TelegramBot(botToken, {
  polling: true,
});


const handlePollingError = (error) => {
  if (error.code === "EFATAL") {
    console.log("Polling error EFATAL detected. Restarting bot...");
    bot.stopPolling().then(() => {
      setTimeout(() => {
        bot.startPolling();
      }, 5000); // Retry after 5 seconds
    });
  } else {
    console.log("Polling error:", error);
    bot.stopPolling().then(() => {
      setTimeout(() => {
        bot.startPolling();
      }, 5000); // Retry after 5 seconds
    });
  }
};

bot.on("polling_error", handlePollingError);

const channelId = "-1002293179152";

const formatHTMLTable = (data) => {
  // Join the first row (header) elements with a space and bold the header
  const header = `<b>${data[0].join(" ")}</b>`;

  // Process the remaining rows
  const rows = data
    .slice(1) // Skip the first row (header)
    .map((row, index) => {
      // Join each row's elements with a space
      const rowString = row.join(" ");
      // Add an empty line after the first row and every third row thereafter
      return index === 0 || index  % 2 === 0 ? `${rowString}\n` : rowString;
    })
    .join("\n"); // Join all rows with a newline character

  // Combine the header and rows with a newline character in between, adding an empty line after the header
  return `${header}\n\n${rows}`;
};

const publishData = () => {
  for (let item of dataToPublish) {
    let message = formatHTMLTable(item);
    console.log(message);
    try {
      bot.sendMessage(channelId, message, {
        parse_mode: "HTML",
        disable_web_page_preview: true,
      });
    } catch (error) {
      console.log("Error publishing data to Telegram", error);
    }
  }
};

const startBot = async () => {
  console.log("🛑 LIVE ---- BOT STARTED  👽👽👽👽");
    try {
      dataToPublish = await getAllCoins();
      lastFetchTime = Date.now();
      publishData();
    } catch (error) {
      console.log("Error in publishData:", error);
      handlePollingError(error);
    }
};

export {startBot, dataToPublish, lastFetchTime}