import sqlite3 from "sqlite3";
sqlite3.verbose();

async function logTrade(tradeLog) {
  let tradeLogs = new sqlite3.Database("./src/server/tradeLogs.db");

  tradeLogs.serialize(() => {
    tradeLogs.run(`
      CREATE TABLE IF NOT EXISTS tradeHistory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profitPercent TEXT,
        profitNet TEXT,
        tradeVolBase TEXT,
        tradeVolQuote TEXT,
        buyAt TEXT,
        sellAt TEXT,
        buyPrice NUMBER,
        sellPrice NUMBER,
        date TEXT,
        time TEXT
      )
    `);

    let stmt = tradeLogs.prepare(`
      INSERT INTO tradeHistory (profitPercent, profitNet, "tradeVolBase", "tradeVolQuote", "buyAt", "sellAt", buyPrice, sellPrice, date, time)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      tradeLog.profitPercent,
      tradeLog.profitNet,
      tradeLog.tradeVolBase,
      tradeLog.tradeVolQuote,
      tradeLog.buyAt,
      tradeLog.sellAt,
      tradeLog.buyPrice,
      tradeLog.sellPrice,
      tradeLog.date,
      tradeLog.time
    );

    stmt.finalize();
  });

  tradeLogs.close();
}

export { logTrade };
