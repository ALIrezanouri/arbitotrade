// adjustedConstantForateLimit in milliseconds to adjust for rate limit (creates a little pause between requests in each loop iteration)
import { fetchAssetData } from "./fetchData.js";
import {
  processFetchedData_IRT,
  processFetchedData_USDT,
  findMinMaxPrices,
} from "./processFetchedData.js";
import { logTradeDB } from "./tradingLogsDB.js";
import { tradeExec } from "./tradeExec.js";
import { sendToTelegram } from "./telbot.js";
import fs from "fs";
import path from "path";

const assetsPath = path.resolve("./src/server/", "assets.json");
const assetsJson = JSON.parse(fs.readFileSync(assetsPath, "utf-8")); // load assets
const assets = assetsJson.crypto.token_irt; // set the market base currency token_usdt or token_irt

const isUSDT_Market = assets === assetsJson.crypto.token_usdt ? true : false; // set the market base currency token_usdt or token_irt

const tradeParamsPath = path.resolve("./src/server/", "trade_params.json");
const tradeParams = JSON.parse(fs.readFileSync(tradeParamsPath, "utf-8")); //load trading fees and request params

const adjustedConstantForateLimit = 1000; // in milliseconds to adjust for rate limit (creates a little pause between requests in each loop iteration)

const min_profit = isUSDT_Market
  ? tradeParams.arbitrage.net_min_profit_usdt
  : tradeParams.arbitrage.net_min_profit_irt;

const max_volume = isUSDT_Market
  ? tradeParams.arbitrage.max_volume_usdt
  : tradeParams.arbitrage.max_volume_irt;

const min_profit_percent = isUSDT_Market
  ? tradeParams.arbitrage.percent_min_profit_usdt
  : tradeParams.arbitrage.percent_min_profit_irt;
const tehranTimeOptions = {
  hour: "numeric",
  minute: "numeric",
  second: "numeric",
  hour12: false,
  timeZone: "Asia/Tehran",
};
const tehranDateOptions = {
  timeZone: "Asia/Tehran",
  year: "numeric",
  month: "numeric",
  day: "numeric",
};

const dateFormatter = new Intl.DateTimeFormat("en-US", tehranDateOptions);
const timeFormatter = new Intl.DateTimeFormat("en-US", tehranTimeOptions);

async function getAllCoins() {
  // *** if no rate limit, we could do this block in parallel ***
  for (let asset of assets) {
    console.log(`Processin: ${asset}`);
    try {
      let fetchedData = await fetchAssetData(asset);
      let firstLineOrders = isUSDT_Market
        ? processFetchedData_USDT(fetchedData)
        : processFetchedData_IRT(fetchedData);
      let bestAskBid = findMinMaxPrices(firstLineOrders, asset);
      console.log(`****** ${asset} data grabbed.....`);
      let bestForSellerPrice = bestAskBid[asset].maxBestBid.price;
      let bestForBuyerPrice = bestAskBid[asset].minBestAsk.price;
      let bestForSellerExchange = bestAskBid[asset].maxBestBid.exchange;
      let bestForBuyerExchange = bestAskBid[asset].minBestAsk.exchange;
      let bestForSellerVol = bestAskBid[asset].maxBestBid.vol;
      let bestForBuyerVol = bestAskBid[asset].minBestAsk.vol;
      let tradeVol = Math.min(bestForSellerVol, bestForBuyerVol);
      let feeSeller =
        tradeParams[bestForSellerExchange].fee.usdt.taker *
        tradeVol *
        bestForSellerPrice;
      let feeBuyer =
        tradeParams[bestForBuyerExchange].fee.usdt.taker *
        tradeVol *
        bestForBuyerPrice;
      let feeTotal = feeSeller + feeBuyer;
      let profitNet =
        (bestForSellerPrice - bestForBuyerPrice) * tradeVol - feeTotal;
      let profitPercent = (profitNet * 100) / (tradeVol * bestForSellerPrice);
      let tradeVolumeFiat = tradeVol * bestForSellerPrice;

      if (
        tradeVol < max_volume &&
        profitNet > min_profit &&
        profitPercent > min_profit_percent
      ) {
        let tradeLog = {
          profitPercent: `${profitPercent.toFixed(3)} %`,
          profitNet: `${profitNet.toFixed(3)} ${asset.split("-")[1]}`,
          tradeVolBase: `${tradeVol} ${asset.split("-")[0]}`,
          tradeVolQuote: `${tradeVolumeFiat} ${asset.split("-")[1]}`,
          buyAt: bestForBuyerExchange,
          sellAt: bestForSellerExchange,
          buyPrice: bestForBuyerPrice,
          sellPrice: bestForSellerPrice,
          date: dateFormatter.format(new Date()),
          time: timeFormatter.format(new Date()),
        };
        try {
          const buyOrder = tradeExec(
            bestForBuyerExchange,
            asset,
            "buy",
            bestForBuyerPrice,
            tradeVol
          ); // execute buy order

          const sellOrder = tradeExec(
            bestForSellerExchange,
            asset,
            "sell",
            bestForSellerPrice,
            tradeVol
          ); // execute sell order

          await Promise.all([buyOrder, sellOrder]);
          // LOG TRADE IN DB -- ONLY LOGS IF BOTH ORDERS ARE SUCCESSFUL
          // if (buyOrder.status == 500 && sellOrder.status == 500) {
          //   await logTradeDB(tradeLog);
          // }
          await logTradeDB(tradeLog); 
          await sendToTelegram(tradeLog);

        } catch (error) {
          console.error(error);
        }

        console.log(
          `*** 🚨🚨🚨 arbitrage opportunity found for ${asset} 🚨🚨🚨***\n`,
          tradeLog
        );
      }
    } catch (error) {
      console.error(`Error in fetching data for ${asset}:`, error);
    }

    await new Promise((resolve) =>
      setTimeout(() => {
        console.log(`*** waiting before grabing next coin data.....`);
        resolve();
      }, adjustedConstantForateLimit)
    );
  }
}

export { getAllCoins };
