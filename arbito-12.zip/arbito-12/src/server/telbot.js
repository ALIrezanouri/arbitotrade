import nodeTelegramBotApi from "node-telegram-bot-api";
import dotenv from "dotenv";

dotenv.config();

const BOT_TOKEN = "8057615049:AAEiY26f68pZ4pz6uUjCBfNpUW1lniTcHJQ";
const CHANNEL_ID = "-1002304688935";

// this is arbitoLogger bot - a different bot from arbito itself

const TelegramBot = nodeTelegramBotApi;

const botToken = BOT_TOKEN;
const bot = new TelegramBot(botToken, {
  polling: true,
  request: {
    agentOptions: {
      keepAlive: true,
      family: 4,
    },
  },
});

function handlePollingError(error) {
  if (error.code === "EFATAL") {
    console.log("Polling error EFATAL detected. Restarting bot...");
    bot.stopPolling().then(() => {
      setTimeout(() => {
        bot.startPolling();
      }, 5000); // Retry after 5 seconds
    });
  } else {
    console.log("Polling error:", error);
    bot.stopPolling().then(() => {
      setTimeout(() => {
        bot.startPolling();
      }, 5000); // Retry after 5 seconds
    });
  }
}

bot.on("polling_error", handlePollingError);

const channelId = CHANNEL_ID;

function formatJsonAsTable(log) {
  return `<pre>
Metric               │ Value       
─────────────────────┼────────────
Profit Percent       │ ${log.profitPercent}  
Profit Net           │ ${log.profitNet}  
Trade Volume (Base)  │ ${log.tradeVolBase}  
Trade Volume (Quote) │ ${log.tradeVolQuote}  
Buy At               │ ${log.buyAt}  
Sell At              │ ${log.sellAt}  
Buy Price            │ ${log.buyPrice}  
Sell Price           │ ${log.sellPrice}  
</pre>`;
}

function publishData(log) {
  let message = formatJsonAsTable(log);
  console.log(message);
  try {
    bot.sendMessage(channelId, message, {
      parse_mode: "HTML",
      disable_web_page_preview: true,
    });
  } catch (error) {
    console.log("Error publishing data to Telegram", error);
  }
}

async function sendToTelegram(log) {
  console.log("sending complete arbitrage log to telegram...");
  try {
    publishData(log);
  } catch (error) {
    console.log("Error in publishData:", error);
    handlePollingError(error);
  }
}

export { sendToTelegram };
